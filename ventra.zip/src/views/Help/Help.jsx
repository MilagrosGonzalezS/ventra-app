// import React from 'react'

function Help() {
  return <div>Help</div>;
}

export default Help;
