function MyTickets() {
  return <div>Mi cuenta</div>;
}

export default MyTickets;
