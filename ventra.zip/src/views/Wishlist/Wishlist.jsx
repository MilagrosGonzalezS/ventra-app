// import React from "react";

function Whishlist() {
  return <div>Mis favoritos</div>;
}

export default Whishlist;
